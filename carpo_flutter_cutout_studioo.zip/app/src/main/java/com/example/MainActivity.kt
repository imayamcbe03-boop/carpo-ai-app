package com.example

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.data.UserPreferences
import com.example.model.AppLanguage
import com.example.ui.screens.BatchScreen
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PassportPrintScreen
import com.example.ui.theme.CarpoAITheme
import com.example.ui.theme.DarkNavyBase
import java.io.InputStream

sealed class Screen {
    object Home : Screen()
    data class Editor(val bitmap: Bitmap) : Screen()
    data class Batch(val uris: List<Uri>) : Screen()
    data class PassportPrint(val bitmap: Bitmap) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val prefs = remember { UserPreferences(context) }
            var currentLanguage by remember { mutableStateOf(prefs.language) }
            var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }

            CarpoAITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkNavyBase
                ) {
                    when (val screen = currentScreen) {
                        is Screen.Home -> {
                            HomeScreen(
                                language = currentLanguage,
                                onLanguageChange = { newLang ->
                                    currentLanguage = newLang
                                    prefs.language = newLang
                                },
                                onPhotoSelected = { uri ->
                                    val bitmap = loadOptimizedBitmap(uri)
                                    if (bitmap != null) {
                                        currentScreen = Screen.Editor(bitmap)
                                    }
                                },
                                onBatchSelected = { uris ->
                                    currentScreen = Screen.Batch(uris)
                                },
                                onSampleSelected = { drawableRes ->
                                    val bitmap = BitmapFactory.decodeResource(resources, drawableRes)
                                    if (bitmap != null) {
                                        currentScreen = Screen.Editor(bitmap)
                                    }
                                }
                            )
                        }

                        is Screen.Editor -> {
                            EditorScreen(
                                sourceBitmap = screen.bitmap,
                                language = currentLanguage,
                                onBack = { currentScreen = Screen.Home },
                                onOpenPassportPrintSheet = { passportBmp ->
                                    currentScreen = Screen.PassportPrint(passportBmp)
                                }
                            )
                        }

                        is Screen.Batch -> {
                            BatchScreen(
                                uris = screen.uris,
                                language = currentLanguage,
                                onBack = { currentScreen = Screen.Home },
                                onSelectForEdit = { bmp ->
                                    currentScreen = Screen.Editor(bmp)
                                }
                            )
                        }

                        is Screen.PassportPrint -> {
                            PassportPrintScreen(
                                cutoutBitmap = screen.bitmap,
                                language = currentLanguage,
                                onBack = { currentScreen = Screen.Home }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun loadOptimizedBitmap(uri: Uri): Bitmap? {
        return try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, boundsOptions)
            inputStream?.close()

            val maxDimension = 1400
            var sampleSize = 1
            while ((boundsOptions.outWidth / sampleSize) > maxDimension || (boundsOptions.outHeight / sampleSize) > maxDimension) {
                sampleSize *= 2
            }

            val decodeStream: InputStream? = contentResolver.openInputStream(uri)
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bmp = BitmapFactory.decodeStream(decodeStream, null, decodeOptions)
            decodeStream?.close()
            bmp
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
