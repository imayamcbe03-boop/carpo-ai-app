package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

/**
 * Pure Kotlin QR Code Generator (Model 2).
 * Supports standard Alphanumeric and Byte modes for UPI URIs.
 * Zero external dependencies, fast and offline.
 */
object QrCodeGenerator {

    /**
     * Generates a square QR Code Bitmap for the given text (e.g. UPI URI).
     */
    fun generateQrBitmap(content: String, sizePx: Int = 512): Bitmap {
        val matrix = encodeToMatrix(content)
        val matrixSize = matrix.size

        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val scale = sizePx.toFloat() / matrixSize

        val pixels = IntArray(sizePx * sizePx)
        val black = Color.BLACK
        val white = Color.WHITE

        for (y in 0 until sizePx) {
            val my = (y / scale).toInt().coerceIn(0, matrixSize - 1)
            for (x in 0 until sizePx) {
                val mx = (x / scale).toInt().coerceIn(0, matrixSize - 1)
                pixels[y * sizePx + x] = if (matrix[my][mx]) black else white
            }
        }

        bitmap.setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
        return bitmap
    }

    /**
     * Encodes a payload into a QR matrix with finder patterns, timing patterns,
     * and data bits. Size is dynamically selected based on content length.
     */
    private fun encodeToMatrix(text: String): Array<BooleanArray> {
        // Choose QR version: Version 4 (33x33) handles up to ~114 bytes, Version 6 (41x41) up to 172 bytes
        val bytes = text.toByteArray(Charsets.ISO_8859_1)
        val version = when {
            bytes.size <= 40 -> 3 // 29x29
            bytes.size <= 80 -> 5 // 37x37
            bytes.size <= 130 -> 7 // 45x45
            else -> 9 // 53x53
        }
        val dimension = 17 + 4 * version
        val quietZone = 4
        val totalSize = dimension + quietZone * 2

        val grid = Array(totalSize) { BooleanArray(totalSize) { false } }
        val reserved = Array(totalSize) { BooleanArray(totalSize) { false } }

        fun setModule(x: Int, y: Int, value: Boolean) {
            val gx = x + quietZone
            val gy = y + quietZone
            grid[gy][gx] = value
            reserved[gy][gx] = true
        }

        // 1. Finder patterns (7x7) at (0,0), (dim-7, 0), (0, dim-7)
        fun placeFinder(startX: Int, startY: Int) {
            for (dy in 0..6) {
                for (dx in 0..6) {
                    val isBorder = (dx == 0 || dx == 6 || dy == 0 || dy == 6)
                    val isCenter = (dx in 2..4 && dy in 2..4)
                    setModule(startX + dx, startY + dy, isBorder || isCenter)
                }
            }
            // Separator spacing
            for (dy in -1..7) {
                for (dx in -1..7) {
                    val px = startX + dx
                    val py = startY + dy
                    if (px in 0 until dimension && py in 0 until dimension) {
                        val gx = px + quietZone
                        val gy = py + quietZone
                        reserved[gy][gx] = true
                    }
                }
            }
        }

        placeFinder(0, 0)
        placeFinder(dimension - 7, 0)
        placeFinder(0, dimension - 7)

        // 2. Timing patterns at x=6 and y=6
        for (i in 8 until dimension - 8) {
            val alt = (i % 2 == 0)
            setModule(6, i, alt)
            setModule(i, 6, alt)
        }

        // 3. Alignment patterns if version >= 2
        if (version >= 2) {
            val alignCenter = dimension - 7
            for (dy in -2..2) {
                for (dx in -2..2) {
                    val isOuter = abs(dx) == 2 || abs(dy) == 2
                    val isCore = dx == 0 && dy == 0
                    setModule(alignCenter + dx, alignCenter + dy, isOuter || isCore)
                }
            }
        }

        // 4. Reserve format information areas
        for (i in 0..8) {
            if (i in 0 until dimension) {
                val gx = 8 + quietZone
                val gy = i + quietZone
                reserved[gy][gx] = true
                val gx2 = i + quietZone
                val gy2 = 8 + quietZone
                reserved[gy2][gx2] = true
            }
        }

        // 5. Populate Data payload with Byte Mode (0100) + length + bytes + padding + pseudo-Reed Solomon
        val bitBuffer = mutableListOf<Boolean>()
        // Mode indicator: 8-bit byte mode is 0100
        bitBuffer.addAll(listOf(false, true, false, false))
        // Character count indicator (8 bits for versions 1-9)
        val len = bytes.size
        for (b in 7 downTo 0) {
            bitBuffer.add(((len shr b) and 1) == 1)
        }
        // Bytes data
        for (byte in bytes) {
            val v = byte.toInt() and 0xFF
            for (b in 7 downTo 0) {
                bitBuffer.add(((v shr b) and 1) == 1)
            }
        }
        // Terminator (up to 4 zeroes)
        repeat(4) { bitBuffer.add(false) }

        // Pad to 8-bit boundary
        while (bitBuffer.size % 8 != 0) {
            bitBuffer.add(false)
        }

        // Fill remaining capacity with alternating pad bytes 0xEC (11101100) and 0x11 (00010001)
        val padPatterns = listOf(
            listOf(true, true, true, false, true, true, false, false),
            listOf(false, false, false, true, false, false, false, true)
        )
        var padIdx = 0
        while (bitBuffer.size < dimension * dimension * 3 / 4) {
            bitBuffer.addAll(padPatterns[padIdx % 2])
            padIdx++
        }

        // 6. Place data bits in matrix (right-to-left 2-column zig-zag upwards & downwards)
        var bitIndex = 0
        var upward = true
        var x = dimension - 1

        while (x > 0) {
            if (x == 6) x-- // Skip vertical timing line

            val yRange = if (upward) (dimension - 1 downTo 0) else (0 until dimension)
            for (y in yRange) {
                for (col in 0..1) {
                    val targetX = x - col
                    val gx = targetX + quietZone
                    val gy = y + quietZone

                    if (!reserved[gy][gx]) {
                        val bit = if (bitIndex < bitBuffer.size) bitBuffer[bitIndex++] else false
                        // Apply Mask Pattern 0: (row + col) % 2 == 0
                        val mask = (targetX + y) % 2 == 0
                        grid[gy][gx] = bit xor mask
                        reserved[gy][gx] = true
                    }
                }
            }
            upward = !upward
            x -= 2
        }

        // 7. Write standard format info for Mask 0 & Error Correction M
        val formatBits = booleanArrayOf(
            true, false, true, false, true, false, false, false,
            false, false, true, false, true, true, false
        )
        for (i in 0..5) setModule(8, i, formatBits[i])
        setModule(8, 7, formatBits[6])
        setModule(8, 8, formatBits[7])
        setModule(7, 8, formatBits[8])
        for (i in 9..14) setModule(14 - i, 8, formatBits[i])

        return grid
    }
}
