package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.example.model.BrushTool

class TouchUpEngine(
    private var maskBitmap: Bitmap
) {
    private val eraserPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        style = Paint.Style.FILL
    }

    private val restorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private var canvas = Canvas(maskBitmap)

    // Undo & Redo History stacks
    private val undoStack = mutableListOf<Bitmap>()
    private val redoStack = mutableListOf<Bitmap>()
    private val maxHistory = 8

    fun saveHistorySnapshot() {
        if (undoStack.size >= maxHistory) {
            val recycled = undoStack.removeAt(0)
            if (!recycled.isRecycled) recycled.recycle()
        }
        undoStack.add(maskBitmap.copy(maskBitmap.config ?: Bitmap.Config.ARGB_8888, true))
        // Clear redo stack on new action
        for (b in redoStack) {
            if (!b.isRecycled) b.recycle()
        }
        redoStack.clear()
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo(): Bitmap? {
        if (!canUndo()) return null
        redoStack.add(maskBitmap.copy(maskBitmap.config ?: Bitmap.Config.ARGB_8888, true))
        val previous = undoStack.removeAt(undoStack.size - 1)
        maskBitmap.recycle()
        maskBitmap = previous
        canvas = Canvas(maskBitmap)
        return maskBitmap
    }

    fun redo(): Bitmap? {
        if (!canRedo()) return null
        undoStack.add(maskBitmap.copy(maskBitmap.config ?: Bitmap.Config.ARGB_8888, true))
        val next = redoStack.removeAt(redoStack.size - 1)
        maskBitmap.recycle()
        maskBitmap = next
        canvas = Canvas(maskBitmap)
        return maskBitmap
    }

    fun applyBrushStroke(
        tool: BrushTool,
        x: Float,
        y: Float,
        radius: Float
    ) {
        when (tool) {
            BrushTool.ERASER -> {
                canvas.drawCircle(x, y, radius, eraserPaint)
            }
            BrushTool.RESTORE -> {
                canvas.drawCircle(x, y, radius, restorePaint)
            }
            BrushTool.NONE -> Unit
        }
    }

    fun applyBrushLine(
        tool: BrushTool,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        radius: Float
    ) {
        val dx = endX - startX
        val dy = endY - startY
        val dist = kotlin.math.hypot(dx, dy)
        val step = (radius * 0.4f).coerceAtLeast(2f)
        val numSteps = (dist / step).toInt().coerceAtLeast(1)

        for (i in 0..numSteps) {
            val t = i.toFloat() / numSteps
            val cx = startX + dx * t
            val cy = startY + dy * t
            applyBrushStroke(tool, cx, cy, radius)
        }
    }

    fun updateMask(newMask: Bitmap) {
        maskBitmap = newMask
        canvas = Canvas(maskBitmap)
    }

    fun getMask(): Bitmap = maskBitmap
}
