package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.ui.graphics.toArgb
import com.example.model.AspectRatioPreset
import com.example.model.BackgroundConfig
import com.example.model.BackgroundType
import com.example.model.BadgeOverlay
import com.example.model.FontPreset
import com.example.model.TextLayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min

object ExportEngine {

    /**
     * Renders high-resolution composite canvas.
     */
    suspend fun renderComposite(
        cutoutBitmap: Bitmap,
        bgConfig: BackgroundConfig,
        aspectRatio: AspectRatioPreset,
        textLayers: List<TextLayer>,
        badges: List<BadgeOverlay>,
        targetWidth: Int = 1200
    ): Bitmap = withContext(Dispatchers.Default) {
        val srcW = cutoutBitmap.width
        val srcH = cutoutBitmap.height

        val outW: Int
        val outH: Int

        if (aspectRatio == AspectRatioPreset.ORIGINAL || aspectRatio.ratio <= 0f) {
            outW = targetWidth
            outH = (targetWidth.toFloat() * (srcH.toFloat() / srcW.toFloat())).toInt()
        } else {
            outW = targetWidth
            outH = (targetWidth / aspectRatio.ratio).toInt()
        }

        val output = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)

        // 1. Render Background
        when (bgConfig.type) {
            BackgroundType.TRANSPARENT -> {
                // Clear to transparent
                canvas.drawColor(AndroidColor.TRANSPARENT, PorterDuff.Mode.CLEAR)
            }
            BackgroundType.SOLID_COLOR -> {
                canvas.drawColor(bgConfig.solidColor.toArgb())
            }
            BackgroundType.ECOMMERCE_WHITE -> {
                canvas.drawColor(AndroidColor.WHITE)
            }
            BackgroundType.GRADIENT, BackgroundType.STUDIO_TEXTURE -> {
                val colors = bgConfig.gradientColors.map { it.toArgb() }.toIntArray()
                val shader = LinearGradient(
                    0f, 0f, 0f, outH.toFloat(),
                    colors, null, Shader.TileMode.CLAMP
                )
                val bgPaint = Paint().apply { this.shader = shader }
                canvas.drawRect(0f, 0f, outW.toFloat(), outH.toFloat(), bgPaint)
            }
        }

        // 2. Position Subject
        // Compute subject rect inside canvas with padding
        val padding = outW * 0.05f
        val availableW = outW - padding * 2
        val availableH = outH - padding * 2

        val scale = min(availableW / srcW.toFloat(), availableH / srcH.toFloat())
        val subjectW = (srcW * scale)
        val subjectH = (srcH * scale)
        val subjectX = (outW - subjectW) / 2f
        val subjectY = (outH - subjectH) / 2f

        val destRect = RectF(subjectX, subjectY, subjectX + subjectW, subjectY + subjectH)

        // 3. E-commerce Floor Reflection
        if (bgConfig.enableReflection && bgConfig.type != BackgroundType.TRANSPARENT) {
            renderFloorReflection(canvas, cutoutBitmap, destRect, bgConfig.reflectionOpacity, bgConfig.reflectionHeightFraction)
        }

        // 4. E-commerce Drop Shadow
        if (bgConfig.enableDropShadow && bgConfig.type != BackgroundType.TRANSPARENT) {
            renderDropShadow(canvas, cutoutBitmap, destRect, bgConfig)
        }

        // 5. Draw Subject Cutout
        val subjectPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(cutoutBitmap, null, destRect, subjectPaint)

        // 6. Draw Badges
        for (badge in badges) {
            renderBadge(canvas, badge, outW.toFloat(), outH.toFloat())
        }

        // 7. Draw Text Layers
        for (layer in textLayers) {
            renderTextLayer(canvas, layer, outW.toFloat(), outH.toFloat())
        }

        output
    }

    private fun renderDropShadow(
        canvas: Canvas,
        cutout: Bitmap,
        destRect: RectF,
        bgConfig: BackgroundConfig
    ) {
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            color = AndroidColor.argb(
                (bgConfig.shadowOpacity * 255).toInt(),
                0, 0, 0
            )
            maskFilter = android.graphics.BlurMaskFilter(
                max(2f, bgConfig.shadowBlurRadius),
                android.graphics.BlurMaskFilter.Blur.NORMAL
            )
        }

        val shadowRect = RectF(
            destRect.left + 8f,
            destRect.top + bgConfig.shadowOffsetY,
            destRect.right + 8f,
            destRect.bottom + bgConfig.shadowOffsetY
        )

        // Extract alpha channel of cutout to cast exact silhouette shadow
        val alphaBitmap = cutout.extractAlpha()
        canvas.drawBitmap(alphaBitmap, null, shadowRect, shadowPaint)
        alphaBitmap.recycle()
    }

    private fun renderFloorReflection(
        canvas: Canvas,
        cutout: Bitmap,
        destRect: RectF,
        opacity: Float,
        heightFraction: Float
    ) {
        val flipMatrix = Matrix().apply {
            preScale(1f, -1f)
        }
        val flipped = Bitmap.createBitmap(
            cutout, 0, 0, cutout.width, cutout.height, flipMatrix, true
        )

        val refHeight = destRect.height() * heightFraction
        val refRect = RectF(
            destRect.left,
            destRect.bottom - 4f,
            destRect.right,
            destRect.bottom + refHeight
        )

        val refPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (opacity * 255).toInt()
        }

        canvas.drawBitmap(flipped, null, refRect, refPaint)
        flipped.recycle()
    }

    private fun renderBadge(
        canvas: Canvas,
        badge: BadgeOverlay,
        canvasW: Float,
        canvasH: Float
    ) {
        val cx = badge.xFraction * canvasW
        val cy = badge.yFraction * canvasH
        val bWidth = 180f * badge.scale
        val bHeight = 70f * badge.scale

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = badge.bgColor.toArgb()
            style = Paint.Style.FILL
        }

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }

        val rect = RectF(cx - bWidth / 2, cy - bHeight / 2, cx + bWidth / 2, cy + bHeight / 2)
        canvas.drawRoundRect(rect, 20f, 20f, bgPaint)
        canvas.drawRoundRect(rect, 20f, 20f, borderPaint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = badge.textColor.toArgb()
            textSize = 28f * badge.scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(badge.title, cx, cy - 2f, textPaint)

        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = badge.textColor.toArgb()
            textSize = 14f * badge.scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            alpha = 210
        }
        canvas.drawText(badge.subtitle, cx, cy + 22f * badge.scale, subPaint)
    }

    private fun renderTextLayer(
        canvas: Canvas,
        layer: TextLayer,
        canvasW: Float,
        canvasH: Float
    ) {
        val tx = layer.xFraction * canvasW
        val ty = layer.yFraction * canvasH

        val typeface = when (layer.fontPreset) {
            FontPreset.BOLD_POSTER -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            FontPreset.MODERN_SANS -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            FontPreset.ELEGANT_SERIF -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
            FontPreset.NEON_SCRIPT -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        val scaledTextSize = layer.fontSizeSp * (canvasW / 450f)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = layer.textColor.toArgb()
            textSize = scaledTextSize
            this.typeface = typeface
            textAlign = Paint.Align.CENTER
        }

        val bounds = Rect()
        textPaint.getTextBounds(layer.text, 0, layer.text.length, bounds)

        // Draw pill badge behind text if enabled
        if (layer.hasBadge) {
            val padX = scaledTextSize * 0.6f
            val padY = scaledTextSize * 0.35f
            val badgeRect = RectF(
                tx - bounds.width() / 2f - padX,
                ty - bounds.height() - padY,
                tx + bounds.width() / 2f + padX,
                ty + padY
            )
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = layer.badgeColor.toArgb()
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(badgeRect, 18f, 18f, badgePaint)
        }

        // Stroke / Outline
        if (layer.strokeWidth > 0f) {
            val strokePaint = Paint(textPaint).apply {
                style = Paint.Style.STROKE
                strokeWidth = layer.strokeWidth * (canvasW / 450f)
                color = layer.strokeColor.toArgb()
            }
            canvas.drawText(layer.text, tx, ty, strokePaint)
        }

        // Fill text
        canvas.drawText(layer.text, tx, ty, textPaint)
    }

    /**
     * Creates an 8-photo layout passport print sheet (4x6 inch standard photographic print paper).
     * Ready to print at studio or photo lab.
     */
    fun generatePassportPrintSheet(passportCutout: Bitmap): Bitmap {
        val sheetW = 1800 // 6 inches @ 300 DPI
        val sheetH = 1200 // 4 inches @ 300 DPI
        val sheet = Bitmap.createBitmap(sheetW, sheetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheet)
        canvas.drawColor(AndroidColor.WHITE)

        // 8 photos arranged in 4 columns x 2 rows
        val photoW = 380f
        val photoH = 490f
        val gapX = (sheetW - (4 * photoW)) / 5f
        val gapY = (sheetH - (2 * photoH)) / 3f

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }

        val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        for (row in 0..1) {
            for (col in 0..3) {
                val left = gapX + col * (photoW + gapX)
                val top = gapY + row * (photoH + gapY)
                val rect = RectF(left, top, left + photoW, top + photoH)

                canvas.drawBitmap(passportCutout, null, rect, photoPaint)
                canvas.drawRect(rect, borderPaint)
            }
        }

        return sheet
    }

    /**
     * Saves bitmap to public Pictures/CarpoAI directory via MediaStore.
     */
    suspend fun saveToGallery(
        context: Context,
        bitmap: Bitmap,
        isPng: Boolean,
        filenamePrefix: String = "CarpoAI"
    ): Uri? = withContext(Dispatchers.IO) {
        val filename = "${filenamePrefix}_${System.currentTimeMillis()}.${if (isPng) "png" else "jpg"}"
        val mimeType = if (isPng) "image/png" else "image/jpeg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/CarpoAI")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext null

        try {
            resolver.openOutputStream(uri)?.use { stream ->
                if (isPng) {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                } else {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            uri
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Creates a share intent for the exported image.
     */
    fun shareImage(context: Context, uri: Uri) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = context.contentResolver.getType(uri) ?: "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Cutout via"))
    }
}
