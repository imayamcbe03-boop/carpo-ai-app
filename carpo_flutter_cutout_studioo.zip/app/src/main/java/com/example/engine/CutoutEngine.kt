package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object CutoutEngine {

    /**
     * Performs automated edge-aware background segmentation.
     * Returns an alpha mask bitmap of the exact same dimensions where
     * foreground pixels have alpha 255 (or soft feathered edge) and background has alpha 0.
     */
    suspend fun removeBackground(
        sourceBitmap: Bitmap,
        sensitivity: Float = 0.42f,
        featherRadius: Int = 2,
        defringe: Boolean = true
    ): Pair<Bitmap, Bitmap> = withContext(Dispatchers.Default) {
        val width = sourceBitmap.width
        val height = sourceBitmap.height

        val pixels = IntArray(width * height)
        sourceBitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        // 1. Sample background seeds from the outer boundary (top, bottom, left, right borders)
        val bgSamples = sampleBorderColors(pixels, width, height)

        // 2. Compute initial binary mask
        val maskPixels = IntArray(width * height)
        val thresholdSq = (sensitivity * 441.67f).let { it * it } // max 3D RGB distance is sqrt(255^2*3) = 441.67

        for (y in 0 until height) {
            for (x in 0 until width) {
                val idx = y * width + x
                val p = pixels[idx]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF

                // Find minimum distance to any border background sample
                var minDistSq = Float.MAX_VALUE
                for (bg in bgSamples) {
                    val bgR = (bg shr 16) and 0xFF
                    val bgG = (bg shr 8) and 0xFF
                    val bgB = bg and 0xFF

                    val dr = (r - bgR).toFloat()
                    val dg = (g - bgG).toFloat()
                    val db = (b - bgB).toFloat()
                    val distSq = dr * dr + dg * dg + db * db
                    if (distSq < minDistSq) {
                        minDistSq = distSq
                    }
                }

                // Check for Green screen / Chroma key dominance
                val isChromaGreen = (g > 100 && g > (r + 35) && g > (b + 35))
                val isChromaBlue = (b > 120 && b > (r + 40) && b > (g + 30))

                val isBg = isChromaGreen || isChromaBlue || (minDistSq < thresholdSq)

                if (isBg) {
                    maskPixels[idx] = 0 // Transparent background
                } else {
                    maskPixels[idx] = AndroidColor.argb(255, 255, 255, 255) // Solid foreground
                }
            }
        }

        // 3. Flood-fill from outer corners to only remove connected background regions,
        // preventing accidental cutouts of matching colors inside the object body.
        refineConnectedBackground(maskPixels, width, height)

        // 4. Apply box-blur feathering to mask for soft edges (avoiding jagged pixellation)
        val finalMaskPixels = if (featherRadius > 0) {
            featherAlphaChannel(maskPixels, width, height, featherRadius)
        } else {
            maskPixels
        }

        val maskBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        maskBitmap.setPixels(finalMaskPixels, 0, width, 0, 0, width, height)

        // 5. Generate composite cutout bitmap with optional defringe
        val cutoutBitmap = generateCutoutBitmap(sourceBitmap, maskBitmap, defringe)

        Pair(maskBitmap, cutoutBitmap)
    }

    /**
     * Samples perimeter colors from corners and border edges.
     */
    private fun sampleBorderColors(pixels: IntArray, width: Int, height: Int): List<Int> {
        val samples = mutableListOf<Int>()
        val stepX = max(1, width / 20)
        val stepY = max(1, height / 20)

        // Top & Bottom rows
        for (x in 0 until width step stepX) {
            samples.add(pixels[x])
            samples.add(pixels[(height - 1) * width + x])
        }
        // Left & Right columns
        for (y in 0 until height step stepY) {
            samples.add(pixels[y * width])
            samples.add(pixels[y * width + (width - 1)])
        }
        // Specific 4 corners
        samples.add(pixels[0])
        samples.add(pixels[width - 1])
        samples.add(pixels[(height - 1) * width])
        samples.add(pixels[(height - 1) * width + (width - 1)])

        return samples.distinct()
    }

    /**
     * Refines mask using flood fill from edges:
     * Only pixels connected to the image boundary are marked as background.
     * Holes inside the subject that don't connect to border are preserved.
     */
    private fun refineConnectedBackground(mask: IntArray, width: Int, height: Int) {
        val visited = BooleanArray(width * height)
        val queue = IntArray(width * height)
        var head = 0
        var tail = 0

        fun push(x: Int, y: Int) {
            if (x in 0 until width && y in 0 until height) {
                val idx = y * width + x
                if (!visited[idx] && mask[idx] == 0) {
                    visited[idx] = true
                    queue[tail++] = idx
                }
            }
        }

        // Enqueue all boundary pixels that were identified as background
        for (x in 0 until width) {
            push(x, 0)
            push(x, height - 1)
        }
        for (y in 0 until height) {
            push(0, y)
            push(width - 1, y)
        }

        val dx = intArrayOf(1, -1, 0, 0)
        val dy = intArrayOf(0, 0, 1, -1)

        while (head < tail) {
            val curr = queue[head++]
            val cx = curr % width
            val cy = curr / width

            for (i in 0..3) {
                val nx = cx + dx[i]
                val ny = cy + dy[i]
                push(nx, ny)
            }
        }

        // Any pixel that was marked 0 (bg) but wasn't reachable from border is kept as foreground!
        for (i in mask.indices) {
            if (mask[i] == 0 && !visited[i]) {
                mask[i] = AndroidColor.argb(255, 255, 255, 255)
            }
        }
    }

    /**
     * Feathers the alpha channel with a fast horizontal and vertical box blur.
     */
    private fun featherAlphaChannel(
        maskPixels: IntArray,
        width: Int,
        height: Int,
        radius: Int
    ): IntArray {
        val r = min(radius, 6)
        val alpha = IntArray(width * height)
        for (i in maskPixels.indices) {
            alpha[i] = (maskPixels[i] ushr 24) and 0xFF
        }

        val tempAlpha = IntArray(width * height)
        val windowSize = 2 * r + 1

        // Horizontal blur
        for (y in 0 until height) {
            val rowOffset = y * width
            var sum = 0
            for (i in -r..r) {
                val clamped = min(max(i, 0), width - 1)
                sum += alpha[rowOffset + clamped]
            }
            for (x in 0 until width) {
                tempAlpha[rowOffset + x] = sum / windowSize
                val removeIdx = min(max(x - r, 0), width - 1)
                val addIdx = min(max(x + r + 1, 0), width - 1)
                sum += alpha[rowOffset + addIdx] - alpha[rowOffset + removeIdx]
            }
        }

        // Vertical blur
        val result = IntArray(width * height)
        for (x in 0 until width) {
            var sum = 0
            for (i in -r..r) {
                val clamped = min(max(i, 0), height - 1)
                sum += tempAlpha[clamped * width + x]
            }
            for (y in 0 until height) {
                val a = sum / windowSize
                result[y * width + x] = AndroidColor.argb(a, 255, 255, 255)
                val removeIdx = min(max(y - r, 0), height - 1)
                val addIdx = min(max(y + r + 1, 0), height - 1)
                sum += tempAlpha[addIdx * width + x] - tempAlpha[removeIdx * width + x]
            }
        }

        return result
    }

    /**
     * Composites original source bitmap with the mask bitmap.
     * Applies defringing on semi-transparent transition pixels.
     */
    fun generateCutoutBitmap(
        sourceBitmap: Bitmap,
        maskBitmap: Bitmap,
        defringe: Boolean = true
    ): Bitmap {
        val width = sourceBitmap.width
        val height = sourceBitmap.height

        val srcPixels = IntArray(width * height)
        val maskPixels = IntArray(width * height)
        val outPixels = IntArray(width * height)

        sourceBitmap.getPixels(srcPixels, 0, width, 0, 0, width, height)
        maskBitmap.getPixels(maskPixels, 0, width, 0, 0, width, height)

        for (i in 0 until width * height) {
            val a = (maskPixels[i] ushr 24) and 0xFF
            if (a == 0) {
                outPixels[i] = 0 // Fully transparent
            } else {
                val src = srcPixels[i]
                val r = (src shr 16) and 0xFF
                val g = (src shr 8) and 0xFF
                val b = src and 0xFF
                outPixels[i] = AndroidColor.argb(a, r, g, b)
            }
        }

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        result.setPixels(outPixels, 0, width, 0, 0, width, height)
        return result
    }
}
