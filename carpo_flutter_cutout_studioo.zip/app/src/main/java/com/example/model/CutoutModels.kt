package com.example.model

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

enum class BrushTool {
    NONE,
    ERASER,
    RESTORE
}

enum class BackgroundType {
    TRANSPARENT,
    SOLID_COLOR,
    GRADIENT,
    ECOMMERCE_WHITE,
    STUDIO_TEXTURE
}

data class BackgroundConfig(
    val type: BackgroundType = BackgroundType.TRANSPARENT,
    val solidColor: Color = Color.White,
    val gradientColors: List<Color> = listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)),
    val textureId: String = "studio_navy",
    // E-Commerce shadow & reflection
    val enableDropShadow: Boolean = false,
    val shadowOpacity: Float = 0.45f,
    val shadowBlurRadius: Float = 16f,
    val shadowOffsetY: Float = 14f,
    val shadowColor: Color = Color.Black,
    val enableReflection: Boolean = false,
    val reflectionOpacity: Float = 0.35f,
    val reflectionHeightFraction: Float = 0.30f,
    // Feather & Halo smoothing
    val featherRadius: Int = 2,
    val defringeStrength: Float = 0.6f
)

enum class AspectRatioPreset(
    val label: String,
    val tamilLabel: String,
    val ratio: Float, // width / height
    val category: String
) {
    ORIGINAL("Original", "அசல்", 0f, "Standard"),
    SQUARE_1_1("1:1 Insta Post", "1:1 இன்ஸ்டா", 1f, "Social"),
    FLEX_3_2("3:2 Flex Banner (3x2ft)", "3x2 ஃபிளெக்ஸ் பேனர்", 1.5f, "Flex & Hoarding"),
    HOARDING_4_3("4:3 Shop Board", "4:3 கடை பலகை", 1.333f, "Flex & Hoarding"),
    YOUTUBE_16_9("16:9 Thumbnail", "16:9 யூடியூப்", 1.777f, "Social"),
    STORY_9_16("9:16 Reel / Story", "9:16 ரீல்ஸ்", 0.5625f, "Social"),
    PASSPORT_IN("35x45mm Indian Passport", "பாஸ்போர்ட் போட்டோ", 0.777f, "Studio Portrait"),
    VISA_US("2x2\" US Visa Photo", "2x2 வீசா போட்டோ", 1f, "Studio Portrait")
}

enum class FontPreset(val displayName: String) {
    BOLD_POSTER("Bold Poster"),
    MODERN_SANS("Modern Sans"),
    ELEGANT_SERIF("Elegant Serif"),
    NEON_SCRIPT("Neon Script")
}

data class TextLayer(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String = "YOUR SHOP NAME",
    val xFraction: Float = 0.5f, // 0.0 to 1.0 (relative to canvas width)
    val yFraction: Float = 0.85f, // 0.0 to 1.0 (relative to canvas height)
    val fontSizeSp: Float = 22f,
    val textColor: Color = Color.Yellow,
    val strokeColor: Color = Color.Black,
    val strokeWidth: Float = 4f,
    val fontPreset: FontPreset = FontPreset.BOLD_POSTER,
    val hasBadge: Boolean = true,
    val badgeColor: Color = Color(0xCC000000),
    val isSelected: Boolean = false
)

data class BadgeOverlay(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "50% OFF",
    val subtitle: String = "SPECIAL OFFER",
    val bgColor: Color = Color(0xFFE50914),
    val textColor: Color = Color.White,
    val xFraction: Float = 0.15f,
    val yFraction: Float = 0.15f,
    val scale: Float = 1.0f
)

data class PricingPlan(
    val id: String,
    val title: String,
    val tamilTitle: String,
    val priceInr: Int,
    val badge: String,
    val features: List<String>,
    val tamilFeatures: List<String>,
    val isRecommended: Boolean = false
) {
    companion object {
        val PLANS = listOf(
            PricingPlan(
                id = "daily_pass",
                title = "24-Hour Express",
                tamilTitle = "1-நாள் எக்ஸ்பிரஸ்",
                priceInr = 9,
                badge = "AFFORDABLE",
                features = listOf(
                    "Unlimited 1-Tap HD Background Removal",
                    "Batch Processing up to 10 photos",
                    "No Watermark & Direct Gallery Export",
                    "Valid for 24 Hours"
                ),
                tamilFeatures = listOf(
                    "வரம்பற்ற HD பின்னணி நீக்கம்",
                    "ஒரே நேரத்தில் 10 போட்டோக்கள்",
                    "வாட்டர்மார்க் இல்லை, நேரடி பதிவிறக்கம்",
                    "24 மணி நேரம் செல்லுபடியாகும்"
                ),
                isRecommended = false
            ),
            PricingPlan(
                id = "weekly_pro",
                title = "Creator Pro (1 Month)",
                tamilTitle = "கிரியேட்டர் ப்ரோ (1 மாதம்)",
                priceInr = 29,
                badge = "POPULAR",
                features = listOf(
                    "All 3x2 Flex & Shop Hoarding Templates",
                    "E-commerce Realistic Shadow & Floor Reflection",
                    "8-Passport Photo Sheet Print Generator",
                    "Full Month Unlimited Commercial Usage"
                ),
                tamilFeatures = listOf(
                    "அனைத்து 3x2 ஃபிளெக்ஸ் பேனர் டெம்ப்ளேட்டுகள்",
                    "ஈ-காமர்ஸ் நிழல் மற்றும் பிரதிபலிப்பு எஃபெக்ட்",
                    "8 பாஸ்போர்ட் போட்டோ பிரிண்ட் ஷீட்",
                    "1 மாதம் முழுமையான வணிக பயன்பாடு"
                ),
                isRecommended = true
            ),
            PricingPlan(
                id = "lifetime_vip",
                title = "Lifetime VIP Master",
                tamilTitle = "வாழ்நாள் VIP மாஸ்டர்",
                priceInr = 99,
                badge = "BEST VALUE",
                features = listOf(
                    "Lifetime Access to All Current & Future Features",
                    "Bulk Cutouts (Unlimited Files at once)",
                    "Direct WhatsApp & Phone Support from Developer",
                    "Support Creator (UPI: 9345275448@fam)"
                ),
                tamilFeatures = listOf(
                    "வாழ்நாள் முழுமைக்கும் அனைத்து அம்சங்களும்",
                    "வரம்பற்ற பலூன்/மொத்த போட்டோ நீக்கம்",
                    "டெவலப்பரிடம் நேரடி வாட்ஸ்அப் உதவி",
                    "டெவலப்பருக்கு ஆதரவு (UPI: 9345275448@fam)"
                ),
                isRecommended = false
            )
        )
    }
}
