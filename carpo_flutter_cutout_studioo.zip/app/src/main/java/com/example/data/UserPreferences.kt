package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppLanguage

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("carpo_ai_prefs", Context.MODE_PRIVATE)

    companion object {
        const val OWNER_UPI_ID = "9345275448@fam"
        const val OWNER_NAME = "Carpo AI Studio"

        fun getUpiUri(amount: Int, planId: String): String {
            val note = "Carpo AI Pro - $planId"
            return "upi://pay?pa=$OWNER_UPI_ID&pn=${android.net.Uri.encode(OWNER_NAME)}&am=$amount&cu=INR&tn=${android.net.Uri.encode(note)}"
        }
    }

    var isVipUnlocked: Boolean
        get() = prefs.getBoolean("is_vip_unlocked", false)
        set(value) = prefs.edit().putBoolean("is_vip_unlocked", value).apply()

    var activePlanId: String
        get() = prefs.getString("active_plan_id", "") ?: ""
        set(value) = prefs.edit().putString("active_plan_id", value).apply()

    var language: AppLanguage
        get() {
            val code = prefs.getString("selected_lang", AppLanguage.ENGLISH.code)
            return AppLanguage.values().firstOrNull { it.code == code } ?: AppLanguage.ENGLISH
        }
        set(value) = prefs.edit().putString("selected_lang", value.code).apply()

    var lastUtr: String
        get() = prefs.getString("last_utr", "") ?: ""
        set(value) = prefs.edit().putString("last_utr", value).apply()

    fun unlockVip(planId: String, utr: String = "") {
        isVipUnlocked = true
        activePlanId = planId
        lastUtr = utr
    }
}
