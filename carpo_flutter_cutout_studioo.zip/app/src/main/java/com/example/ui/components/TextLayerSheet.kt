package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.AppStrings
import com.example.model.FontPreset
import com.example.model.TextLayer
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ElectricGold
import com.example.ui.theme.NeonCyan

@Composable
fun TextLayerSheet(
    textLayers: List<TextLayer>,
    language: AppLanguage,
    onAddTextLayer: (TextLayer) -> Unit,
    onRemoveTextLayer: (String) -> Unit,
    onUpdateTextLayer: (TextLayer) -> Unit
) {
    var newText by remember { mutableStateOf("") }
    var selectedFont by remember { mutableStateOf(FontPreset.BOLD_POSTER) }
    var textColor by remember { mutableStateOf(Color.Yellow) }
    var hasBadge by remember { mutableStateOf(true) }
    var badgeColor by remember { mutableStateOf(Color(0xDD000000)) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkNavySurface)
            .padding(14.dp)
            .testTag("text_layer_sheet")
    ) {
        Text(
            text = AppStrings.get("tab_text", language),
            style = androidx.compose.material3.MaterialTheme.typography.titleSmall,
            color = NeonCyan,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Quick suggestions row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "🏢 YOUR SHOP NAME",
                "📞 +91 98765 43210",
                "🔥 50% SPECIAL DISCOUNT",
                "📍 MAIN BAZAAR ROAD",
                "⭐ BEST QUALITY GUARANTEED"
            ).forEach { preset ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkNavyCard)
                        .clickable { newText = preset }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(preset, fontSize = 11.sp, color = Color.LightGray)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input & Add Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newText,
                onValueChange = { newText = it },
                placeholder = { Text("Enter text, phone or shop name...", fontSize = 12.sp, color = Color.Gray) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("text_input_field"),
                singleLine = true,
                shape = RoundedCornerShape(10.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    if (newText.isNotBlank()) {
                        onAddTextLayer(
                            TextLayer(
                                text = newText,
                                fontPreset = selectedFont,
                                textColor = textColor,
                                hasBadge = hasBadge,
                                badgeColor = badgeColor,
                                yFraction = 0.82f - (textLayers.size * 0.1f)
                            )
                        )
                        newText = ""
                    }
                },
                modifier = Modifier
                    .height(52.dp)
                    .testTag("add_text_button"),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Text",
                    tint = Color(0xFF00363D)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Style controls (Font Presets)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FontPreset.values().forEach { font ->
                FilterChip(
                    selected = selectedFont == font,
                    onClick = { selectedFont = font },
                    label = { Text(font.displayName, fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Color palette for text
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Color:", fontSize = 11.sp, color = Color.LightGray)
            listOf(
                Color.Yellow, Color.White, Color.Red,
                Color.Cyan, Color.Green, Color(0xFFFF9900), Color(0xFFFF3366)
            ).forEach { c ->
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(c)
                        .border(if (textColor == c) 2.dp else 0.5.dp, if (textColor == c) NeonCyan else Color.White, CircleShape)
                        .clickable { textColor = c }
                )
            }
        }

        // Existing layers list
        if (textLayers.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text("Active Layers on Canvas (Drag to reposition):", fontSize = 11.sp, color = NeonCyan)
            Spacer(modifier = Modifier.height(6.dp))
            textLayers.forEach { layer ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(layer.text, color = layer.textColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        IconButton(
                            onClick = { onRemoveTextLayer(layer.id) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Layer",
                                tint = Color(0xFFFF4D4D),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
