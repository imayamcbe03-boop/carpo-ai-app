package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.TouchUpEngine
import com.example.model.AspectRatioPreset
import com.example.model.BackgroundConfig
import com.example.model.BackgroundType
import com.example.model.BadgeOverlay
import com.example.model.BrushTool
import com.example.model.TextLayer
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun CanvasEditor(
    modifier: Modifier = Modifier,
    cutoutBitmap: Bitmap,
    touchUpEngine: TouchUpEngine?,
    brushTool: BrushTool,
    brushRadius: Float,
    bgConfig: BackgroundConfig,
    aspectRatioPreset: AspectRatioPreset,
    textLayers: List<TextLayer>,
    badges: List<BadgeOverlay>,
    onMaskModified: () -> Unit,
    onTextLayerMoved: (layerId: String, newX: Float, newY: Float) -> Unit,
    isZoomMode: Boolean = false
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }

    // Track active touch for brush cursor preview
    var brushCursorPos by remember { mutableStateOf<Offset?>(null) }
    var lastStrokePoint by remember { mutableStateOf<PointF?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("canvas_editor_box"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("interactive_canvas")
                .pointerInput(brushTool, isZoomMode, cutoutBitmap) {
                    if (isZoomMode || brushTool == BrushTool.NONE) {
                        // Pinch to zoom and two-finger pan
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(0.7f, 5.0f)
                            panOffset += pan
                        }
                    } else {
                        // Brush stroke mode (Eraser / Restore)
                        detectDragGestures(
                            onDragStart = { offset ->
                                touchUpEngine?.saveHistorySnapshot()
                                brushCursorPos = offset
                                val pt = screenToBitmapCoordinates(
                                    offset, size.width.toFloat(), size.height.toFloat(),
                                    cutoutBitmap.width, cutoutBitmap.height, scale, panOffset, aspectRatioPreset
                                )
                                if (pt != null) {
                                    lastStrokePoint = pt
                                    val bmpRadius = brushRadius * (cutoutBitmap.width.toFloat() / size.width.toFloat()) / scale
                                    touchUpEngine?.applyBrushStroke(brushTool, pt.x, pt.y, bmpRadius)
                                    onMaskModified()
                                }
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val offset = change.position
                                brushCursorPos = offset
                                val pt = screenToBitmapCoordinates(
                                    offset, size.width.toFloat(), size.height.toFloat(),
                                    cutoutBitmap.width, cutoutBitmap.height, scale, panOffset, aspectRatioPreset
                                )
                                if (pt != null) {
                                    val bmpRadius = brushRadius * (cutoutBitmap.width.toFloat() / size.width.toFloat()) / scale
                                    val last = lastStrokePoint
                                    if (last != null) {
                                        touchUpEngine?.applyBrushLine(
                                            brushTool, last.x, last.y, pt.x, pt.y, bmpRadius
                                        )
                                    } else {
                                        touchUpEngine?.applyBrushStroke(brushTool, pt.x, pt.y, bmpRadius)
                                    }
                                    lastStrokePoint = pt
                                    onMaskModified()
                                }
                            },
                            onDragEnd = {
                                brushCursorPos = null
                                lastStrokePoint = null
                            },
                            onDragCancel = {
                                brushCursorPos = null
                                lastStrokePoint = null
                            }
                        )
                    }
                }
        ) {
            val canvasW = size.width
            val canvasH = size.height

            // 1. Draw Checkerboard pattern (for transparent background)
            drawCheckerboard(canvasW, canvasH)

            // 2. Compute aspect ratio viewport box
            val viewRect = computeAspectRect(canvasW, canvasH, aspectRatioPreset, cutoutBitmap.width, cutoutBitmap.height)

            // Apply pan & zoom to the viewRect
            val zoomedW = viewRect.width * scale
            val zoomedH = viewRect.height * scale
            val zoomedX = (canvasW - zoomedW) / 2f + panOffset.x
            val zoomedY = (canvasH - zoomedH) / 2f + panOffset.y

            // 3. Draw Background inside target viewport
            drawActiveBackground(bgConfig, zoomedX, zoomedY, zoomedW, zoomedH)

            // 4. Draw E-commerce Drop Shadow if enabled
            if (bgConfig.enableDropShadow && bgConfig.type != BackgroundType.TRANSPARENT) {
                drawRect(
                    color = Color.Black.copy(alpha = bgConfig.shadowOpacity * 0.5f),
                    topLeft = Offset(zoomedX + 6f * scale, zoomedY + zoomedH * 0.92f + bgConfig.shadowOffsetY * scale),
                    size = Size(zoomedW * 0.95f, 16.dp.toPx() * scale)
                )
            }

            // 5. Draw Cutout Bitmap
            drawImage(
                image = cutoutBitmap.asImageBitmap(),
                dstOffset = androidx.compose.ui.unit.IntOffset(zoomedX.toInt(), zoomedY.toInt()),
                dstSize = androidx.compose.ui.unit.IntSize(zoomedW.toInt(), zoomedH.toInt())
            )

            // 6. Draw Viewport Outline
            drawRect(
                color = Color(0x6600E5FF),
                topLeft = Offset(zoomedX, zoomedY),
                size = Size(zoomedW, zoomedH),
                style = Stroke(width = 2.dp.toPx())
            )

            // 7. Draw brush cursor ring if dragging
            if (brushCursorPos != null && brushTool != BrushTool.NONE) {
                drawCircle(
                    color = if (brushTool == BrushTool.ERASER) Color(0xFFFF3366) else Color(0xFF00E5FF),
                    radius = brushRadius,
                    center = brushCursorPos!!,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }

        // Draggable Text Layers Overlay
        for (layer in textLayers) {
            var layerOffset by remember(layer.id) {
                mutableStateOf(Offset(layer.xFraction, layer.yFraction))
            }

            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (layerOffset.x * 300).roundToInt(),
                            (layerOffset.y * 300).roundToInt()
                        )
                    }
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (layer.hasBadge) layer.badgeColor else Color.Transparent)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .pointerInput(layer.id) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val newX = (layerOffset.x + dragAmount.x / 300f).coerceIn(0.05f, 0.95f)
                            val newY = (layerOffset.y + dragAmount.y / 300f).coerceIn(0.05f, 0.95f)
                            layerOffset = Offset(newX, newY)
                            onTextLayerMoved(layer.id, newX, newY)
                        }
                    }
            ) {
                Text(
                    text = layer.text,
                    color = layer.textColor,
                    fontSize = layer.fontSizeSp.sp,
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

private fun DrawScope.drawCheckerboard(width: Float, height: Float) {
    val square = 24.dp.toPx()
    val color1 = Color(0xFF1E2638)
    val color2 = Color(0xFF141926)

    var y = 0f
    var row = 0
    while (y < height) {
        var x = 0f
        var col = 0
        while (x < width) {
            val c = if ((row + col) % 2 == 0) color1 else color2
            drawRect(c, topLeft = Offset(x, y), size = Size(square, square))
            x += square
            col++
        }
        y += square
        row++
    }
}

private fun DrawScope.drawActiveBackground(
    bgConfig: BackgroundConfig,
    x: Float,
    y: Float,
    w: Float,
    h: Float
) {
    when (bgConfig.type) {
        BackgroundType.TRANSPARENT -> Unit
        BackgroundType.SOLID_COLOR -> {
            drawRect(bgConfig.solidColor, topLeft = Offset(x, y), size = Size(w, h))
        }
        BackgroundType.ECOMMERCE_WHITE -> {
            drawRect(Color.White, topLeft = Offset(x, y), size = Size(w, h))
        }
        BackgroundType.GRADIENT, BackgroundType.STUDIO_TEXTURE -> {
            val brush = Brush.verticalGradient(bgConfig.gradientColors, startY = y, endY = y + h)
            drawRect(brush, topLeft = Offset(x, y), size = Size(w, h))
        }
    }
}

private fun computeAspectRect(
    canvasW: Float,
    canvasH: Float,
    aspect: AspectRatioPreset,
    bmpW: Int,
    bmpH: Int
): RectSize {
    val ratio = if (aspect == AspectRatioPreset.ORIGINAL || aspect.ratio <= 0f) {
        bmpW.toFloat() / bmpH.toFloat()
    } else {
        aspect.ratio
    }

    val maxW = canvasW * 0.92f
    val maxH = canvasH * 0.92f

    val w: Float
    val h: Float
    if (maxW / ratio <= maxH) {
        w = maxW
        h = maxW / ratio
    } else {
        h = maxH
        w = maxH * ratio
    }

    return RectSize((canvasW - w) / 2f, (canvasH - h) / 2f, w, h)
}

private data class RectSize(val x: Float, val y: Float, val width: Float, val height: Float)

private fun screenToBitmapCoordinates(
    screenPos: Offset,
    canvasW: Float,
    canvasH: Float,
    bmpW: Int,
    bmpH: Int,
    scale: Float,
    pan: Offset,
    aspect: AspectRatioPreset
): PointF? {
    val viewRect = computeAspectRect(canvasW, canvasH, aspect, bmpW, bmpH)
    val zoomedW = viewRect.width * scale
    val zoomedH = viewRect.height * scale
    val zoomedX = (canvasW - zoomedW) / 2f + pan.x
    val zoomedY = (canvasH - zoomedH) / 2f + pan.y

    val relX = screenPos.x - zoomedX
    val relY = screenPos.y - zoomedY

    if (relX < 0 || relX > zoomedW || relY < 0 || relY > zoomedH) {
        return null
    }

    val bmpX = (relX / zoomedW) * bmpW
    val bmpY = (relY / zoomedH) * bmpH

    return PointF(bmpX, bmpY)
}
