package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.AppStrings
import com.example.model.AspectRatioPreset
import com.example.model.BackgroundConfig
import com.example.model.BackgroundType
import com.example.model.BadgeOverlay
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.ElectricGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink

enum class StudioTab {
    BACKDROP,
    ECOMMERCE,
    FLEX_BANNER,
    PORTRAIT_STUDIO,
    TOUCHUP_BRUSH
}

@Composable
fun TemplateSelector(
    activeTab: StudioTab,
    bgConfig: BackgroundConfig,
    aspectRatio: AspectRatioPreset,
    language: AppLanguage,
    onBgConfigChange: (BackgroundConfig) -> Unit,
    onAspectRatioChange: (AspectRatioPreset) -> Unit,
    onAddBadge: (BadgeOverlay) -> Unit,
    onOpenPassportSheet: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkNavyCard)
            .padding(12.dp)
            .testTag("template_selector_panel")
    ) {
        when (activeTab) {
            StudioTab.BACKDROP -> {
                BackdropPanel(bgConfig, language, onBgConfigChange)
            }
            StudioTab.ECOMMERCE -> {
                EcommercePanel(bgConfig, language, onBgConfigChange, onAddBadge)
            }
            StudioTab.FLEX_BANNER -> {
                FlexBannerPanel(bgConfig, aspectRatio, language, onBgConfigChange, onAspectRatioChange)
            }
            StudioTab.PORTRAIT_STUDIO -> {
                PortraitStudioPanel(bgConfig, aspectRatio, language, onBgConfigChange, onAspectRatioChange, onOpenPassportSheet)
            }
            StudioTab.TOUCHUP_BRUSH -> {
                // Brush controls are rendered separately in the editor
            }
        }
    }
}

@Composable
private fun BackdropPanel(
    bgConfig: BackgroundConfig,
    language: AppLanguage,
    onBgConfigChange: (BackgroundConfig) -> Unit
) {
    Text(
        text = AppStrings.get("tab_background", language),
        style = MaterialTheme.typography.labelMedium,
        color = NeonCyan,
        fontWeight = FontWeight.Bold
    )
    Spacer(modifier = Modifier.height(8.dp))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Transparent PNG Chip
        FilterChip(
            selected = bgConfig.type == BackgroundType.TRANSPARENT,
            onClick = { onBgConfigChange(bgConfig.copy(type = BackgroundType.TRANSPARENT)) },
            label = { Text(AppStrings.get("transparent", language), fontSize = 12.sp) },
            leadingIcon = {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .border(1.dp, Color.White, CircleShape)
                )
            },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f))
        )

        // Pure White Chip
        FilterChip(
            selected = bgConfig.type == BackgroundType.ECOMMERCE_WHITE,
            onClick = { onBgConfigChange(bgConfig.copy(type = BackgroundType.ECOMMERCE_WHITE)) },
            label = { Text(AppStrings.get("pure_white", language), fontSize = 12.sp) },
            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f))
        )

        // Solid Color Presets
        val solids = listOf(
            Color.White, Color(0xFFF1F5F9), Color(0xFF0F172A),
            Color(0xFFDC2626), Color(0xFF2563EB), Color(0xFF059669), Color(0xFFD97706)
        )
        solids.forEach { color ->
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(color)
                    .border(
                        if (bgConfig.type == BackgroundType.SOLID_COLOR && bgConfig.solidColor == color) 2.5.dp else 1.dp,
                        if (bgConfig.type == BackgroundType.SOLID_COLOR && bgConfig.solidColor == color) NeonCyan else Color.Gray,
                        CircleShape
                    )
                    .clickable {
                        onBgConfigChange(bgConfig.copy(type = BackgroundType.SOLID_COLOR, solidColor = color))
                    }
            )
        }
    }
}

@Composable
private fun EcommercePanel(
    bgConfig: BackgroundConfig,
    language: AppLanguage,
    onBgConfigChange: (BackgroundConfig) -> Unit,
    onAddBadge: (BadgeOverlay) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = AppStrings.get("drop_shadow", language),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
            Switch(
                checked = bgConfig.enableDropShadow,
                onCheckedChange = { onBgConfigChange(bgConfig.copy(enableDropShadow = it)) },
                colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
            )
        }

        if (bgConfig.enableDropShadow) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Shadow Blur", fontSize = 11.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.width(8.dp))
                Slider(
                    value = bgConfig.shadowBlurRadius,
                    onValueChange = { onBgConfigChange(bgConfig.copy(shadowBlurRadius = it)) },
                    valueRange = 4f..40f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = AppStrings.get("floor_reflection", language),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
            Switch(
                checked = bgConfig.enableReflection,
                onCheckedChange = { onBgConfigChange(bgConfig.copy(enableReflection = it)) },
                colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text("Product Badges (Tap to add):", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                BadgeOverlay(title = "50% OFF", subtitle = "MEGA SALE", bgColor = Color(0xFFDC2626)),
                BadgeOverlay(title = "NEW ARRIVAL", subtitle = "2026 EDITION", bgColor = Color(0xFF0284C7)),
                BadgeOverlay(title = "BESTSELLER", subtitle = "TOP RATED", bgColor = Color(0xFFD97706)),
                BadgeOverlay(title = "FREE DELIVERY", subtitle = "FAST SHIPPING", bgColor = Color(0xFF059669)),
                BadgeOverlay(title = "★ 4.9 RATED", subtitle = "TRUSTED SHOP", bgColor = Color(0xFF7C3AED))
            ).forEach { badge ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(badge.bgColor)
                        .clickable { onAddBadge(badge) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(badge.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun FlexBannerPanel(
    bgConfig: BackgroundConfig,
    aspectRatio: AspectRatioPreset,
    language: AppLanguage,
    onBgConfigChange: (BackgroundConfig) -> Unit,
    onAspectRatioChange: (AspectRatioPreset) -> Unit
) {
    Column {
        Text("Banner Aspect Ratio (Flex & Hoarding):", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                AspectRatioPreset.FLEX_3_2,
                AspectRatioPreset.HOARDING_4_3,
                AspectRatioPreset.YOUTUBE_16_9,
                AspectRatioPreset.SQUARE_1_1,
                AspectRatioPreset.STORY_9_16
            ).forEach { preset ->
                FilterChip(
                    selected = aspectRatio == preset,
                    onClick = { onAspectRatioChange(preset) },
                    label = { Text(if (language == AppLanguage.TAMIL) preset.tamilLabel else preset.label, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.2f))
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("Commercial Gradient Backdrops:", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val gradientPresets = listOf(
                listOf(Color(0xFF800020), Color(0xFFFFD700)), // Royal Tamil Gold & Crimson
                listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)), // Deep Cyber Navy
                listOf(Color(0xFF1E3C72), Color(0xFF2A5298)), // Royal Blue Commercial
                listOf(Color(0xFF11998E), Color(0xFF38EF7D)), // Emerald Gradient
                listOf(Color(0xFFFF416C), Color(0xFFFF4B2B)), // Sunset Burst
                listOf(Color(0xFF4A00E0), Color(0xFF8E2DE2))  // Electric Purple
            )
            gradientPresets.forEach { grads ->
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Brush.verticalGradient(grads))
                        .border(
                            if (bgConfig.type == BackgroundType.GRADIENT && bgConfig.gradientColors == grads) 2.dp else 0.5.dp,
                            if (bgConfig.type == BackgroundType.GRADIENT && bgConfig.gradientColors == grads) NeonCyan else Color.White,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable {
                            onBgConfigChange(
                                bgConfig.copy(
                                    type = BackgroundType.GRADIENT,
                                    gradientColors = grads
                                )
                            )
                        }
                )
            }
        }
    }
}

@Composable
private fun PortraitStudioPanel(
    bgConfig: BackgroundConfig,
    aspectRatio: AspectRatioPreset,
    language: AppLanguage,
    onBgConfigChange: (BackgroundConfig) -> Unit,
    onAspectRatioChange: (AspectRatioPreset) -> Unit,
    onOpenPassportSheet: () -> Unit
) {
    Column {
        Text("Studio Passport Standards:", fontSize = 11.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = aspectRatio == AspectRatioPreset.PASSPORT_IN,
                onClick = {
                    onAspectRatioChange(AspectRatioPreset.PASSPORT_IN)
                    onBgConfigChange(bgConfig.copy(type = BackgroundType.SOLID_COLOR, solidColor = Color(0xFF2563EB)))
                },
                label = { Text("35x45mm Indian Passport", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = aspectRatio == AspectRatioPreset.VISA_US,
                onClick = {
                    onAspectRatioChange(AspectRatioPreset.VISA_US)
                    onBgConfigChange(bgConfig.copy(type = BackgroundType.ECOMMERCE_WHITE))
                },
                label = { Text("2x2\" US Visa (White)", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 8-Photo Print Sheet CTA
        Button(
            onClick = onOpenPassportSheet,
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .testTag("open_passport_sheet_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricGold),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Print,
                contentDescription = null,
                tint = Color(0xFF0F172A),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = AppStrings.get("passport_print_title", language),
                color = Color(0xFF0F172A),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}
