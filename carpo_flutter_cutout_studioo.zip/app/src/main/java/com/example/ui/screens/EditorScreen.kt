package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserPreferences
import com.example.engine.CutoutEngine
import com.example.engine.ExportEngine
import com.example.engine.TouchUpEngine
import com.example.model.AppLanguage
import com.example.model.AppStrings
import com.example.model.AspectRatioPreset
import com.example.model.BackgroundConfig
import com.example.model.BackgroundType
import com.example.model.BadgeOverlay
import com.example.model.BrushTool
import com.example.model.TextLayer
import com.example.ui.components.CanvasEditor
import com.example.ui.components.StudioTab
import com.example.ui.components.TemplateSelector
import com.example.ui.components.TextLayerSheet
import com.example.ui.components.UpiPaymentDialog
import com.example.ui.theme.DarkNavyBase
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ElectricGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    sourceBitmap: Bitmap,
    language: AppLanguage,
    onBack: () -> Unit,
    onOpenPassportPrintSheet: (Bitmap) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { UserPreferences(context) }

    // Navigation back press handler
    BackHandler { onBack() }

    var isProcessing by remember { mutableStateOf(true) }
    var maskBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var cutoutBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var touchUpEngine by remember { mutableStateOf<TouchUpEngine?>(null) }

    // Editor settings
    var brushTool by remember { mutableStateOf(BrushTool.NONE) }
    var brushRadius by remember { mutableFloatStateOf(24f) }
    var sensitivity by remember { mutableFloatStateOf(0.42f) }
    var featherRadius by remember { mutableStateOf(2) }
    var isZoomMode by remember { mutableStateOf(false) }
    var isComparingOriginal by remember { mutableStateOf(false) }

    var activeTab by remember { mutableStateOf(StudioTab.BACKDROP) }
    var bgConfig by remember { mutableStateOf(BackgroundConfig()) }
    var aspectRatio by remember { mutableStateOf(AspectRatioPreset.ORIGINAL) }

    val textLayers = remember { mutableStateListOf<TextLayer>() }
    val badges = remember { mutableStateListOf<BadgeOverlay>() }

    // Dialog & Sheet States
    var showExportSheet by remember { mutableStateOf(false) }
    var showTextSheet by remember { mutableStateOf(false) }
    var showUpiDialog by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var lastSavedUri by remember { mutableStateOf<Uri?>(null) }

    // Run initial 1-tap automated background removal
    fun executeAutoCutout() {
        scope.launch {
            isProcessing = true
            val (mask, cutout) = CutoutEngine.removeBackground(
                sourceBitmap = sourceBitmap,
                sensitivity = sensitivity,
                featherRadius = featherRadius,
                defringe = true
            )
            maskBitmap = mask
            cutoutBitmap = cutout
            touchUpEngine = TouchUpEngine(mask)
            isProcessing = false
        }
    }

    LaunchedEffect(Unit) {
        executeAutoCutout()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = DarkNavyBase
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Top App Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("editor_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    // Undo & Redo
                    IconButton(
                        onClick = {
                            val newMask = touchUpEngine?.undo()
                            if (newMask != null && cutoutBitmap != null) {
                                maskBitmap = newMask
                                cutoutBitmap = CutoutEngine.generateCutoutBitmap(sourceBitmap, newMask)
                            }
                        },
                        enabled = touchUpEngine?.canUndo() == true,
                        modifier = Modifier.testTag("undo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (touchUpEngine?.canUndo() == true) Color.White else Color.Gray
                        )
                    }

                    IconButton(
                        onClick = {
                            val newMask = touchUpEngine?.redo()
                            if (newMask != null && cutoutBitmap != null) {
                                maskBitmap = newMask
                                cutoutBitmap = CutoutEngine.generateCutoutBitmap(sourceBitmap, newMask)
                            }
                        },
                        enabled = touchUpEngine?.canRedo() == true,
                        modifier = Modifier.testTag("redo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (touchUpEngine?.canRedo() == true) Color.White else Color.Gray
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Zoom / Pan Mode toggle
                    IconButton(
                        onClick = {
                            isZoomMode = !isZoomMode
                            if (isZoomMode) brushTool = BrushTool.NONE
                        },
                        modifier = Modifier.testTag("zoom_mode_toggle")
                    ) {
                        Icon(
                            imageVector = if (isZoomMode) Icons.Default.PanTool else Icons.Default.ZoomIn,
                            contentDescription = "Zoom & Pan",
                            tint = if (isZoomMode) NeonCyan else Color.White
                        )
                    }

                    // Hold to Compare Original
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isComparingOriginal) NeonPink else DarkNavyCard)
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = {
                                        isComparingOriginal = true
                                        tryAwaitRelease()
                                        isComparingOriginal = false
                                    }
                                )
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("compare_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Compare", fontSize = 11.sp, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // VIP Upgrade trigger
                    IconButton(
                        onClick = { showUpiDialog = true },
                        modifier = Modifier.testTag("editor_vip_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "VIP",
                            tint = ElectricGold
                        )
                    }

                    // Export HD Button
                    Button(
                        onClick = { showExportSheet = true },
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("export_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = Color(0xFF00363D),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Export",
                            color = Color(0xFF00363D),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Main Canvas Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (isProcessing) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = NeonCyan)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "AI detecting sharp edges...",
                            color = NeonCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (isComparingOriginal) {
                    Image(
                        bitmap = sourceBitmap.asImageBitmap(),
                        contentDescription = "Original Photo",
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (cutoutBitmap != null) {
                    CanvasEditor(
                        cutoutBitmap = cutoutBitmap!!,
                        touchUpEngine = touchUpEngine,
                        brushTool = brushTool,
                        brushRadius = brushRadius,
                        bgConfig = bgConfig,
                        aspectRatioPreset = aspectRatio,
                        textLayers = textLayers,
                        badges = badges,
                        onMaskModified = {
                            val mask = touchUpEngine?.getMask()
                            if (mask != null) {
                                cutoutBitmap = CutoutEngine.generateCutoutBitmap(sourceBitmap, mask)
                            }
                        },
                        onTextLayerMoved = { layerId, newX, newY ->
                            val idx = textLayers.indexOfFirst { it.id == layerId }
                            if (idx != -1) {
                                textLayers[idx] = textLayers[idx].copy(xFraction = newX, yFraction = newY)
                            }
                        },
                        isZoomMode = isZoomMode
                    )
                }
            }

            // Brush Adjustment Bar (when Touch-up Brush is active)
            AnimatedVisibility(visible = activeTab == StudioTab.TOUCHUP_BRUSH) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkNavySurface)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Tool Selector
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = brushTool == BrushTool.ERASER,
                                onClick = {
                                    brushTool = BrushTool.ERASER
                                    isZoomMode = false
                                },
                                label = { Text(AppStrings.get("tool_eraser", language), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonPink.copy(alpha = 0.3f))
                            )
                            FilterChip(
                                selected = brushTool == BrushTool.RESTORE,
                                onClick = {
                                    brushTool = BrushTool.RESTORE
                                    isZoomMode = false
                                },
                                label = { Text(AppStrings.get("tool_restore", language), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = NeonCyan.copy(alpha = 0.3f))
                            )
                            FilterChip(
                                selected = brushTool == BrushTool.NONE,
                                onClick = {
                                    brushTool = BrushTool.NONE
                                    isZoomMode = true
                                },
                                label = { Text(AppStrings.get("tool_none", language), fontSize = 11.sp) }
                            )
                        }

                        Text("Radius: ${brushRadius.toInt()}px", fontSize = 11.sp, color = Color.LightGray)
                    }

                    // Brush Radius Slider
                    Slider(
                        value = brushRadius,
                        onValueChange = { brushRadius = it },
                        valueRange = 6f..80f,
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )

                    // Edge Sensitivity / Re-Cutout Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Auto Sensitivity", fontSize = 11.sp, color = ElectricGold)
                        Slider(
                            value = sensitivity,
                            onValueChange = {
                                sensitivity = it
                                executeAutoCutout()
                            },
                            valueRange = 0.2f..0.7f,
                            modifier = Modifier.width(180.dp),
                            colors = SliderDefaults.colors(thumbColor = ElectricGold, activeTrackColor = ElectricGold)
                        )
                    }
                }
            }

            // Template / Backdrop / E-Commerce / Flex Options Panel
            if (activeTab != StudioTab.TOUCHUP_BRUSH) {
                TemplateSelector(
                    activeTab = activeTab,
                    bgConfig = bgConfig,
                    aspectRatio = aspectRatio,
                    language = language,
                    onBgConfigChange = { bgConfig = it },
                    onAspectRatioChange = { aspectRatio = it },
                    onAddBadge = { badges.add(it) },
                    onOpenPassportSheet = {
                        if (cutoutBitmap != null) {
                            onOpenPassportPrintSheet(cutoutBitmap!!)
                        }
                    }
                )
            }

            // Bottom Navigation Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkNavyCard)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StudioTabItem(
                    label = AppStrings.get("tab_background", language),
                    icon = Icons.Default.FormatColorFill,
                    isSelected = activeTab == StudioTab.BACKDROP,
                    onClick = { activeTab = StudioTab.BACKDROP }
                )
                StudioTabItem(
                    label = AppStrings.get("tab_touchup", language),
                    icon = Icons.Default.Brush,
                    isSelected = activeTab == StudioTab.TOUCHUP_BRUSH,
                    onClick = {
                        activeTab = StudioTab.TOUCHUP_BRUSH
                        if (brushTool == BrushTool.NONE) brushTool = BrushTool.ERASER
                    }
                )
                StudioTabItem(
                    label = AppStrings.get("tab_ecommerce", language),
                    icon = Icons.Default.ShoppingBag,
                    isSelected = activeTab == StudioTab.ECOMMERCE,
                    onClick = {
                        activeTab = StudioTab.ECOMMERCE
                        bgConfig = bgConfig.copy(type = BackgroundType.ECOMMERCE_WHITE, enableDropShadow = true)
                    }
                )
                StudioTabItem(
                    label = AppStrings.get("tab_flex", language),
                    icon = Icons.Default.Layers,
                    isSelected = activeTab == StudioTab.FLEX_BANNER,
                    onClick = {
                        activeTab = StudioTab.FLEX_BANNER
                        aspectRatio = AspectRatioPreset.FLEX_3_2
                    }
                )
                StudioTabItem(
                    label = AppStrings.get("tab_passport", language),
                    icon = Icons.Default.FitScreen,
                    isSelected = activeTab == StudioTab.PORTRAIT_STUDIO,
                    onClick = {
                        activeTab = StudioTab.PORTRAIT_STUDIO
                        aspectRatio = AspectRatioPreset.PASSPORT_IN
                    }
                )
                StudioTabItem(
                    label = AppStrings.get("tab_text", language),
                    icon = Icons.Default.TextFields,
                    isSelected = false,
                    onClick = { showTextSheet = true }
                )
            }
        }

        // Text & Branding Bottom Sheet
        if (showTextSheet) {
            ModalBottomSheet(
                onDismissRequest = { showTextSheet = false },
                containerColor = DarkNavySurface
            ) {
                TextLayerSheet(
                    textLayers = textLayers,
                    language = language,
                    onAddTextLayer = { textLayers.add(it) },
                    onRemoveTextLayer = { id -> textLayers.removeAll { it.id == id } },
                    onUpdateTextLayer = { updated ->
                        val i = textLayers.indexOfFirst { it.id == updated.id }
                        if (i != -1) textLayers[i] = updated
                    }
                )
            }
        }

        // Export Bottom Sheet
        if (showExportSheet && cutoutBitmap != null) {
            ModalBottomSheet(
                onDismissRequest = { showExportSheet = false },
                containerColor = DarkNavySurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "High-Resolution Export Service",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Direct download & Print-ready formats without compression",
                        fontSize = 11.sp,
                        color = Color.LightGray
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isExporting) {
                        CircularProgressIndicator(color = NeonCyan)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Rendering Full Resolution Canvas...", fontSize = 12.sp, color = NeonCyan)
                    } else {
                        // 1. Transparent PNG
                        Button(
                            onClick = {
                                scope.launch {
                                    isExporting = true
                                    val composite = ExportEngine.renderComposite(
                                        cutoutBitmap = cutoutBitmap!!,
                                        bgConfig = bgConfig.copy(type = BackgroundType.TRANSPARENT),
                                        aspectRatio = AspectRatioPreset.ORIGINAL,
                                        textLayers = emptyList(),
                                        badges = emptyList(),
                                        targetWidth = 1400
                                    )
                                    val uri = ExportEngine.saveToGallery(context, composite, isPng = true, filenamePrefix = "CarpoCutout")
                                    isExporting = false
                                    if (uri != null) {
                                        lastSavedUri = uri
                                        Toast.makeText(context, AppStrings.get("save_success", language), Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("export_png_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = AppStrings.get("export_png", language),
                                color = Color(0xFF00363D),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 2. High-Res JPG with selected backdrop & text
                        Button(
                            onClick = {
                                scope.launch {
                                    isExporting = true
                                    val composite = ExportEngine.renderComposite(
                                        cutoutBitmap = cutoutBitmap!!,
                                        bgConfig = bgConfig,
                                        aspectRatio = aspectRatio,
                                        textLayers = textLayers,
                                        badges = badges,
                                        targetWidth = 1400
                                    )
                                    val uri = ExportEngine.saveToGallery(context, composite, isPng = false, filenamePrefix = "CarpoDesign")
                                    isExporting = false
                                    if (uri != null) {
                                        lastSavedUri = uri
                                        Toast.makeText(context, AppStrings.get("save_success", language), Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("export_jpg_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = AppStrings.get("export_jpg", language),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 3. Share Button
                        if (lastSavedUri != null) {
                            OutlinedButton(
                                onClick = {
                                    ExportEngine.shareImage(context, lastSavedUri!!)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("share_cutout_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(AppStrings.get("share_image", language), color = Color.White)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // UPI Payment Dialog
        if (showUpiDialog) {
            UpiPaymentDialog(
                language = language,
                onDismiss = { showUpiDialog = false },
                onUnlockSuccess = {
                    showUpiDialog = false
                }
            )
        }
    }
}

@Composable
private fun StudioTabItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) NeonCyan else Color.LightGray,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) NeonCyan else Color.Gray
        )
    }
}
