package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors: Futuristic Neon Cutout Studio Palette
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanLight = Color(0xFF6EFFFF)
val NeonCyanDark = Color(0xFF00B2CC)

val NeonPink = Color(0xFFFF2E93)
val NeonPurple = Color(0xFF9D4EDD)
val ElectricGold = Color(0xFFFFB703)
val EmeraldGreen = Color(0xFF06D6A0)

// Surfaces & Backgrounds
val DarkNavyBase = Color(0xFF0B0E17)
val DarkNavySurface = Color(0xFF141926)
val DarkNavyCard = Color(0xFF1E2638)
val DarkNavyCardBorder = Color(0xFF2E3A54)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Accents
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val UpiBlue = Color(0xFF0284C7)
