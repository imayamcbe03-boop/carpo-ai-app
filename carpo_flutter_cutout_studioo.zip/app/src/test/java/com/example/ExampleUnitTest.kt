package com.example

import android.graphics.Bitmap
import com.example.data.UserPreferences
import com.example.engine.CutoutEngine
import com.example.engine.QrCodeGenerator
import com.example.model.PricingPlan
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleUnitTest {

    @Test
    fun verifyOwnerUpiConfiguration() {
        assertEquals("9345275448@fam", UserPreferences.OWNER_UPI_ID)
        val uri = UserPreferences.getUpiUri(29, "weekly_pro")
        assertTrue("UPI URI must contain owner UPI ID", uri.contains("pa=9345275448@fam"))
        assertTrue("UPI URI must contain amount", uri.contains("am=29"))
        assertTrue("UPI URI must contain currency INR", uri.contains("cu=INR"))
    }

    @Test
    fun verifyAffordablePricingPlans() {
        val plans = PricingPlan.PLANS
        assertEquals(3, plans.size)
        assertEquals(9, plans[0].priceInr)
        assertEquals(29, plans[1].priceInr)
        assertEquals(99, plans[2].priceInr)
    }

    @Test
    fun verifyQrCodeGeneration() {
        val upiString = UserPreferences.getUpiUri(9, "daily_pass")
        val bitmap = QrCodeGenerator.generateQrBitmap(upiString, 256)
        assertNotNull(bitmap)
        assertEquals(256, bitmap.width)
        assertEquals(256, bitmap.height)
    }

    @Test
    fun verifyCutoutEngineBasic() = runBlocking {
        // Create simple 50x50 bitmap with green border and white center
        val bmp = Bitmap.createBitmap(50, 50, Bitmap.Config.ARGB_8888)
        val (mask, cutout) = CutoutEngine.removeBackground(bmp, 0.4f)
        assertNotNull(mask)
        assertNotNull(cutout)
        assertEquals(50, mask.width)
        assertEquals(50, cutout.width)
    }
}
